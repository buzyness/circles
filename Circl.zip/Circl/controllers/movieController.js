//Import the dependencies
const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
//Creating a Router
var router = express.Router();
//Link
const Movie = mongoose.model('Movie');

//Router Controller for READ request
router.get('/', (req, res) => {
    res.render("movie/movieAddEdit", {
        viewTitle: "Add to my List"
    });
});

//Router Controller for UPDATE request
router.post('/', (req, res) => {
    if (req.body._id == '')
        insertIntoMongoDB(req, res);
    else
        updateIntoMongoDB(req, res);
});

//Creating function to insert data into MongoDB
function insertIntoMongoDB(req, res) {
    var movie = new Movie();

    movie.movieName = req.body.movieName;
    movie.movieIMDBId = req.body.movieIMDBId;
    movie.movieRating = req.body.movieRating;
    movie.movieImgLink = req.body.movieImgLink;
    movie.save((err, doc) => {
        if (!err)
            res.redirect('movie/list');
        else
            console.log('Error during record insertion : ' + err);
    });



}

//Creating a function to update data in MongoDB
function updateIntoMongoDB(req, res) {
    Movie.findOneAndUpdate({ _id: req.body._id }, req.body, { new: true }, (err, doc) => {
        if (!err) { res.redirect('movie/list'); }
        else {
            if (err.name == 'ValidationError') {
                handleValidationError(err, req.body);
                res.render("movie/movieAddEdit", {
                    //Retaining value to be displayed in the child view
                    viewTitle: 'Update Movie Details',
                    employee: req.body
                });
            }
            else
                console.log('Error during updating the record: ' + err);
        }
    });
}

//Router to retrieve the complete list of available courses
router.get('/list', (req, res) => {


    var imdbObj;
    //console.log(imdbObj);
    fetchImg('tt7286456', function(imdbObj){
        // Here you have access to your variable
        console.log(imdbObj);
        
    });

    console.log("LLLLLL");

    Movie.find((err, docs) => {
        if (!err) {

            // create context Object with 'usersDocuments' key
            const context = {
                usersDocuments: docs.map(document => {

                    return {
                        movieName: document.movieName,
                        movieIMDBId: document.movieIMDBId
                        //movieImgLink: movObj.Poster
                    }
                })
            }


            res.render("movie/list", {
                list: context.usersDocuments
            });
        }
        else {
            console.log('Failed to retrieve the Course List: ' + err);
        }
    });


});

//Creating a function to implement input validations
function handleValidationError(err, body) {
    for (field in err.errors) {
        switch (err.errors[field].path) {
            case 'movieName':
                body['movieNameError'] = err.errors[field].message;
                break;
            default:
                break;
        }
    }
}



//Fetch and store the img
function fetchImg(imdbMovId, callback) {

    const axios = require('axios');
    var movObj;
    const url = 'http://www.omdbapi.com/?';
    const tokenId = 'apikey=40170272';
    var movId = '&i=' + imdbMovId;
    var completeUrl = url + tokenId + movId

    axios.get(completeUrl)

        .then(response => {
            //console.log(response.data);            
            //console.log(response.data.Poster);
            movObj = response.data;
            //console.log(typeof(movObj));
            //console.log(movObj.Title);
            //console.log(">>" + typeof(tokenId));            
            return callback(movObj);
        })
        .catch(error => {
            console.log(error);
        });


}

//Router to update a course using it's ID
router.get('/:id', (req, res) => {
    Movie.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.render("movie/movieAddEdit", {
                viewTitle: "Update Movie Details",
                movie: doc
            });
        }
    });
});

//Router Controller for DELETE request
router.get('/delete/:id', (req, res) => {
    Movie.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) {
            res.redirect('/movie/list');
        }
        else { console.log('Failed to Delete Course Details: ' + err); }
    });
});

module.exports = router;