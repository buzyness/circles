require('./models/mongodb');
const express = require('express');
var app = express();
const path = require('path');
const exphb = require('express-handlebars');
const bodyparser = require('body-parser');

//Controller Movie
const movieController = require('./controllers/movieController');
app.use(bodyparser.urlencoded({
  extended: true
}));


app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname + '/index.html'));
});

app.use(bodyparser.json());
 
//Configuring Express middleware for the handlebars
app.set('views', path.join(__dirname, '/views/'));
app.engine('hbs', exphb({ extname: 'hbs', defaultLayout: 'mainLayout', layoutDir: __dirname + 'views/layouts/' }));
app.set('view engine', 'hbs');


app.get('/about', function (req, res) {
  res.sendFile(path.join(__dirname + '/about.html'));
})
app.get('/contact', function (req, res) {
  res.sendFile(path.join(__dirname + '/contact.html'));
})
app.post('/savedata', function (req, res) {
  res.send('Data saved successfully');
})
// similarly we can for put and delete
var server = app.listen(5000, function () {
  console.log('Node server is running..');
});

//Set the Controller path which will be responding the user actions
app.use('/movie', movieController);