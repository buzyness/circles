npm init
npm i --s express express-handlebars mongoose body-parser
npm i -g nodemon