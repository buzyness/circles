const mongoose  = require ("mongoose");
mongoose.connect("mongodb+srv://dbadmin:dbpwdnew@cluster0-q2w2s.gcp.mongodb.net/movies?retryWrites=true&w=majority",{useNewUrlParser: true}, (err) => {
    if (!err) {
    console.log('Successfully Established Connection with MongoDB')
    }
    else {
    console.log('Failed to Establish Connection with MongoDB with Error: '+ err)
    }
    });
     
    //Connecting Node and MongoDB
    require('./movie.model');




// const MongoClient = require('mongodb').MongoClient;
// const uri = "mongodb+srv://dbadmin:dbpwdnew@cluster0-q2w2s.gcp.mongodb.net/test?retryWrites=true&w=majority";
// const client = new MongoClient(uri, { useNewUrlParser: true });
// client.connect(err => {
//     const collection = client.db("test").collection("devices");
//     // perform actions on the collection object
//     client.close();
// });
