const mongoose = require('mongoose');

//Attributes of the Course object
var movieSchema = new mongoose.Schema({
    movieName: {
        type: String,
        required: 'This field is required!'
    },
    movieIMDBId: {
        type: String
    },
    movieRating: {
        type: String
    },
    movieImgLink: {
        type: String
    },
},
{
    toObject: {
      virtuals: true,
    },
    toJSON: {
      virtuals: true,
    },

    
});

mongoose.model('Movie', movieSchema);